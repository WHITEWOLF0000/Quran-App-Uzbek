
'use client';
import QuranReader from './components/QuranReader';

export default function Home() {
  return (
    <div className="min-h-screen w-full max-w-md mx-auto bg-white">
      <QuranReader />
    </div>
  );
}
